package ro.mooncity.plus;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MoonCityPlus.ID)
public class MoonCityPlus {
    public static final String ID = "mooncityplus";

    public MoonCityPlus() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Reg.init(bus);
        bus.addListener(Reg::tab);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
        MinecraftForge.EVENT_BUS.register(Jobs.class);
        MinecraftForge.EVENT_BUS.register(Cmds.class);
    }
}
