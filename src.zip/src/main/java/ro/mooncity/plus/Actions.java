package ro.mooncity.plus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Dispecer pentru toate actiunile trimise de client. */
public class Actions {

    public static void handle(ServerPlayer sp, String a, CompoundTag t) {
        switch (a) {
            case "mdt" -> openMdt(sp);
            case "jobs" -> Jobs.open(sp);
            case "job_join" -> Jobs.join(sp, t.getString("job"));
            case "job_quit" -> Jobs.quit(sp);
            case "checkout" -> Shop.openCheckout(sp);
            case "shop_pay" -> Shop.pay(sp, t.getBoolean("cash"));
            case "shop_clear" -> Shop.clear(sp);
            case "shop_remove" -> Shop.remove(sp, t.getInt("i"));
            case "vehicle" -> VehicleBridge.open(sp);
            case "veh_fuel" -> VehicleBridge.fuel(sp, t.getInt("units"));
            case "veh_engine" -> VehicleBridge.engine(sp, t.getInt("tier"));
            case "veh_wheel" -> VehicleBridge.wheel(sp, t.getInt("type"));
            case "veh_color" -> VehicleBridge.color(sp, t.getInt("rgb"));
            case "elec_submit" -> Jobs.submitElectric(sp, t.getIntArray("seq"));
            default -> { }
        }
    }

    public static void openMdt(ServerPlayer sp) {
        CompoundTag d = new CompoundTag();
        d.putString("name", sp.getGameProfile().getName());
        d.putLong("cash", PlusData.cash(sp));
        d.putLong("bank", PlusData.bank(sp));
        d.putString("job", Jobs.nameOf(Jobs.current(sp)));
        d.putInt("level", Jobs.level(sp));
        ListTag players = new ListTag();
        for (ServerPlayer p : sp.server.getPlayerList().getPlayers()) players.add(StringTag.valueOf(p.getGameProfile().getName()));
        d.put("players", players);
        Net.open(sp, Net.MDT, d);
    }

    public static void msg(ServerPlayer sp, String s) { sp.displayClientMessage(Component.literal(s), true); }
}
