package ro.mooncity.plus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Acces la banii MoonCity (PlayerPersisted/mooncity: cash, bank) si la datele noastre. */
public class PlusData {
    private static CompoundTag sub(CompoundTag parent, String key) {
        if (!parent.contains(key, 10)) parent.put(key, new CompoundTag());
        return parent.getCompound(key);
    }

    public static CompoundTag persisted(Player p) { return sub(p.getPersistentData(), "PlayerPersisted"); }
    public static CompoundTag mc(Player p) { return sub(persisted(p), "mooncity"); }
    public static CompoundTag plus(Player p) { return sub(persisted(p), "mooncityplus"); }

    public static long cash(Player p) { return mc(p).getLong("cash"); }
    public static long bank(Player p) { return mc(p).getLong("bank"); }
    public static void setCash(Player p, long v) { mc(p).putLong("cash", Math.max(0, v)); }
    public static void setBank(Player p, long v) { mc(p).putLong("bank", Math.max(0, v)); }

    /** Apeleaza ro.mooncity.Net.sync(ServerPlayer) daca modul mooncity e prezent. */
    public static void sync(ServerPlayer sp) {
        try {
            Class.forName("ro.mooncity.Net").getMethod("sync", ServerPlayer.class).invoke(null, sp);
        } catch (Throwable ignored) { }
    }
}
