package ro.mooncity.plus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Cos de cumparaturi (salvat pe jucator) + plata la casa. */
public class Shop {

    private static ListTag cart(ServerPlayer p) {
        CompoundTag r = PlusData.plus(p);
        if (!r.contains("cart", 9)) r.put("cart", new ListTag());
        return r.getList("cart", 10);
    }

    public static void addToCart(ServerPlayer sp, ItemStack stack, int price) {
        String id = ForgeRegistries.ITEMS.getKey(stack.getItem()).toString();
        ListTag l = cart(sp);
        for (Tag t : l) {
            CompoundTag c = (CompoundTag) t;
            if (id.equals(c.getString("id")) && c.getInt("price") == price) {
                c.putInt("count", Math.min(64 * 9, c.getInt("count") + 1));
                Actions.msg(sp, "+1 " + stack.getHoverName().getString() + " (in cos: " + c.getInt("count") + ") - mergi la casa sa platesti");
                return;
            }
        }
        CompoundTag c = new CompoundTag();
        c.putString("id", id);
        c.putInt("price", price);
        c.putInt("count", 1);
        l.add(c);
        Actions.msg(sp, "Adaugat in cos: " + stack.getHoverName().getString() + " - $" + price);
    }

    private static long total(ListTag l) {
        long s = 0;
        for (Tag t : l) { CompoundTag c = (CompoundTag) t; s += (long) c.getInt("price") * c.getInt("count"); }
        return s;
    }

    public static void openCheckout(ServerPlayer sp) {
        ListTag l = cart(sp);
        CompoundTag d = new CompoundTag();
        d.put("cart", l.copy());
        d.putLong("total", total(l));
        d.putLong("cash", PlusData.cash(sp));
        d.putLong("bank", PlusData.bank(sp));
        Net.open(sp, Net.CHECKOUT, d);
    }

    public static void clear(ServerPlayer sp) { cart(sp).clear(); openCheckout(sp); }

    public static void remove(ServerPlayer sp, int i) {
        ListTag l = cart(sp);
        if (i >= 0 && i < l.size()) l.remove(i);
        openCheckout(sp);
    }

    public static void pay(ServerPlayer sp, boolean cash) {
        ListTag l = cart(sp);
        long total = total(l);
        if (l.isEmpty() || total <= 0) { Actions.msg(sp, "Cosul e gol."); return; }
        if (cash) {
            if (PlusData.cash(sp) < total) { Actions.msg(sp, "Nu ai destui bani cash."); openCheckout(sp); return; }
            PlusData.setCash(sp, PlusData.cash(sp) - total);
        } else {
            if (PlusData.bank(sp) < total) { Actions.msg(sp, "Fonduri insuficiente pe card."); openCheckout(sp); return; }
            PlusData.setBank(sp, PlusData.bank(sp) - total);
        }
        for (Tag t : l) {
            CompoundTag c = (CompoundTag) t;
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(c.getString("id")));
            if (item == null) continue;
            int left = c.getInt("count");
            while (left > 0) {
                int n = Math.min(left, item.getMaxStackSize());
                ItemStack s = new ItemStack(item, n);
                if (!sp.getInventory().add(s)) sp.drop(s, false);
                left -= n;
            }
        }
        l.clear();
        PlusData.sync(sp);
        Actions.msg(sp, "Plata reusita: $" + total + ". Multumim!");
        openCheckout(sp);
    }
}
