package ro.mooncity.plus;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class Cmds {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        var d = e.getDispatcher();
        d.register(Commands.literal("mdt").executes(c -> { Actions.openMdt(c.getSource().getPlayerOrException()); return 1; }));
        d.register(Commands.literal("joburi").executes(c -> { Jobs.open(c.getSource().getPlayerOrException()); return 1; }));
        d.register(Commands.literal("vehiculmeniu").executes(c -> { VehicleBridge.open(c.getSource().getPlayerOrException()); return 1; }));
        d.register(Commands.literal("shop").requires(s -> s.hasPermission(2))
                .then(Commands.literal("price").then(Commands.argument("suma", IntegerArgumentType.integer(1, 1000000)).executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    HitResult h = sp.pick(6, 0, false);
                    if (h instanceof BlockHitResult b && sp.level().getBlockEntity(b.getBlockPos()) instanceof ShelfBE be) {
                        be.price = IntegerArgumentType.getInteger(c, "suma");
                        be.sync();
                        Actions.msg(sp, "Pret setat: $" + be.price);
                        return 1;
                    }
                    Actions.msg(sp, "Uita-te la un raft.");
                    return 0;
                })))
                .then(Commands.literal("clear").executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    HitResult h = sp.pick(6, 0, false);
                    if (h instanceof BlockHitResult b && sp.level().getBlockEntity(b.getBlockPos()) instanceof ShelfBE be) {
                        be.item = net.minecraft.world.item.ItemStack.EMPTY;
                        be.price = 0;
                        be.sync();
                        return 1;
                    }
                    return 0;
                })));
    }
}
