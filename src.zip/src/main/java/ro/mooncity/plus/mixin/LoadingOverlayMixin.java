package ro.mooncity.plus.mixin;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ro.mooncity.plus.client.MoonLoading;

@Mixin(LoadingOverlay.class)
public abstract class LoadingOverlayMixin {
    @Shadow private float currentProgress;

    @Inject(method = "render", at = @At("TAIL"))
    private void mooncityplus$render(GuiGraphics g, int mx, int my, float pt, CallbackInfo ci) {
        MoonLoading.render(g, currentProgress);
    }
}
