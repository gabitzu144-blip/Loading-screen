package ro.mooncity.plus;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;

/**
 * Leaga meniul K de MrCrayfish Vehicle (si Moonvehicles, care extinde PoweredVehicleEntity).
 * Totul prin reflexie, deci modul porneste si fara vehicle instalat.
 */
public class VehicleBridge {
    public static final String[] TIERS = {"iron", "gold", "diamond", "netherite"};
    public static final int[] TIER_PRICE = {2000, 5000, 12000, 25000};
    public static final String[] WHEELS = {"standard", "sports", "racing", "off_road", "snow", "all_terrain", "plastic"};
    public static final int[] WHEEL_PRICE = {300, 1500, 3000, 1200, 1000, 1800, 100};
    public static final int FUEL_PRICE = 2; // per unitate

    private static Class<?> powered() {
        try { return Class.forName("com.mrcrayfish.vehicle.entity.PoweredVehicleEntity"); }
        catch (Throwable t) { return null; }
    }

    private static Entity find(ServerPlayer sp) {
        Class<?> c = powered();
        if (c == null) return null;
        Entity v = sp.getVehicle();
        if (v != null && c.isInstance(v)) return v;
        List<Entity> l = sp.level().getEntities(sp, sp.getBoundingBox().inflate(8), c::isInstance);
        return l.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(sp))).orElse(null);
    }

    private static Object call(Object o, String name, Class<?>[] types, Object... args) throws Exception {
        for (Class<?> k = o.getClass(); k != null; k = k.getSuperclass()) {
            try {
                Method m = k.getDeclaredMethod(name, types);
                m.setAccessible(true);
                return m.invoke(o, args);
            } catch (NoSuchMethodException ignored) { }
        }
        throw new NoSuchMethodException(name);
    }

    private static Object call(Object o, String name) throws Exception { return call(o, name, new Class<?>[0]); }

    private static String path(Object stack) {
        if (!(stack instanceof ItemStack s) || s.isEmpty()) return "";
        return BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }

    public static void open(ServerPlayer sp) {
        CompoundTag d = new CompoundTag();
        Entity e = find(sp);
        d.putBoolean("found", e != null);
        d.putLong("cash", PlusData.cash(sp));
        if (e != null) {
            try {
                d.putString("name", e.getDisplayName().getString());
                d.putFloat("fuel", (Float) call(e, "getCurrentFuel"));
                d.putFloat("cap", (Float) call(e, "getFuelCapacity"));
                d.putString("engine", path(call(e, "getEngineStack")));
                try { d.putString("wheel", path(call(e, "getWheelStack"))); } catch (Throwable ignored) { d.putString("wheel", ""); }
            } catch (Throwable t) { d.putBoolean("found", false); }
        }
        Net.open(sp, Net.VEHICLE, d);
    }

    private static boolean pay(ServerPlayer sp, long price) {
        if (PlusData.cash(sp) < price) { Actions.msg(sp, "Nu ai destui bani cash ($" + price + ")."); return false; }
        PlusData.setCash(sp, PlusData.cash(sp) - price);
        PlusData.sync(sp);
        return true;
    }

    public static void fuel(ServerPlayer sp, int units) {
        Entity e = find(sp);
        if (e == null) return;
        try {
            float cur = (Float) call(e, "getCurrentFuel"), cap = (Float) call(e, "getFuelCapacity");
            int add = (int) Math.min(Math.max(units, 0), Math.floor(cap - cur));
            if (add <= 0) { Actions.msg(sp, "Rezervorul e plin."); return; }
            if (!pay(sp, (long) add * FUEL_PRICE)) return;
            call(e, "setCurrentFuel", new Class<?>[]{float.class}, cur + add);
            Actions.msg(sp, "Alimentat +" + add + " benzină.");
        } catch (Throwable t) { Actions.msg(sp, "Vehiculul nu suportă alimentare."); }
        open(sp);
    }

    public static void engine(ServerPlayer sp, int tier) {
        Entity e = find(sp);
        if (e == null || tier < 0 || tier >= TIERS.length) return;
        try {
            String cur = path(call(e, "getEngineStack"));
            String type = cur.contains("_large_") ? "large" : cur.contains("_electric_") ? "electric" : "small";
            Item it = BuiltInRegistries.ITEM.get(new ResourceLocation("vehicle", TIERS[tier] + "_" + type + "_engine"));
            if (it == null || it == net.minecraft.world.item.Items.AIR) { Actions.msg(sp, "Motor indisponibil."); return; }
            if (!pay(sp, TIER_PRICE[tier])) return;
            call(e, "setEngineStack", new Class<?>[]{ItemStack.class}, new ItemStack(it));
            Actions.msg(sp, "Motor montat: " + TIERS[tier] + " " + type);
        } catch (Throwable t) { Actions.msg(sp, "Vehiculul nu are motor schimbabil."); }
        open(sp);
    }

    public static void wheel(ServerPlayer sp, int type) {
        Entity e = find(sp);
        if (e == null || type < 0 || type >= WHEELS.length) return;
        try {
            Item it = BuiltInRegistries.ITEM.get(new ResourceLocation("vehicle", WHEELS[type] + "_wheel"));
            try {
                Object can = call(e, "canChangeWheels");
                if (can instanceof Boolean b && !b) { Actions.msg(sp, "Acest vehicul nu permite schimbarea roților."); return; }
            } catch (Throwable ignored) { }
            if (!pay(sp, WHEEL_PRICE[type])) return;
            call(e, "setWheelStack", new Class<?>[]{ItemStack.class}, new ItemStack(it));
            Actions.msg(sp, "Roți montate: " + WHEELS[type]);
        } catch (Throwable t) { Actions.msg(sp, "Nu se pot schimba roțile la acest vehicul."); }
        open(sp);
    }

    public static void color(ServerPlayer sp, int rgb) {
        Entity e = find(sp);
        if (e == null) return;
        try {
            if (!pay(sp, 200)) return;
            call(e, "setColor", new Class<?>[]{int.class}, rgb & 0xFFFFFF);
            Actions.msg(sp, "Culoare/interior schimbat.");
        } catch (Throwable t) { Actions.msg(sp, "Vehiculul nu poate fi vopsit."); }
        open(sp);
    }
}
