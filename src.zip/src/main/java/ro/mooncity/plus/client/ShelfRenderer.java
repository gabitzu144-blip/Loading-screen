package ro.mooncity.plus.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import ro.mooncity.plus.ShelfBE;
import ro.mooncity.plus.ShelfBlock;

public class ShelfRenderer implements BlockEntityRenderer<ShelfBE> {
    public ShelfRenderer(BlockEntityRendererProvider.Context ctx) { }

    @Override
    public void render(ShelfBE be, float pt, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (be.item.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        Direction d = be.getBlockState().getValue(ShelfBlock.FACING);
        float rot = (d.toYRot() + 180f) % 360f;
        float[] ys = {2f / 16f + 0.13f, 9f / 16f + 0.13f};
        float[] xs = {0.27f, 0.5f, 0.73f};
        for (float y : ys) {
            for (float x : xs) {
                ps.pushPose();
                ps.translate(0.5, 0, 0.5);
                ps.mulPose(Axis.YP.rotationDegrees(-rot));
                ps.translate(x - 0.5, y, -0.1);
                ps.scale(0.28f, 0.28f, 0.28f);
                mc.getItemRenderer().renderStatic(be.item, ItemDisplayContext.FIXED, light, overlay, ps, buf, be.getLevel(), 0);
                ps.popPose();
            }
        }
        if (be.price > 0) {
            String t = "$" + be.price;
            Font f = mc.font;
            ps.pushPose();
            ps.translate(0.5, 1.2, 0.5);
            ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
            ps.scale(-0.025f, -0.025f, 0.025f);
            f.drawInBatch(t, -f.width(t) / 2f, 0, 0xFFFFE066, false, ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0x66000000, LightTexture.FULL_BRIGHT);
            ps.popPose();
        }
    }
}
