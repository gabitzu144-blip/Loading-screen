package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;

/** Meniu vehicul: benzina, motor, roti, culoare/interior (MrCrayfish Vehicle + Moonvehicles). */
public class VehicleScreen extends ScaledScreen {
    private static final String[] TIERS = {"Iron", "Gold", "Diamond", "Netherite"};
    private static final int[] TIER_PRICE = {2000, 5000, 12000, 25000};
    private static final String[] WHEELS = {"Standard", "Sports", "Racing", "Off-Road", "Snow", "All-Terrain", "Plastic"};
    private static final int[] WHEEL_PRICE = {300, 1500, 3000, 1200, 1000, 1800, 100};
    private static final int[] COLORS = {0xFFFFFF, 0x111111, 0xD32F2F, 0x1976D2, 0x388E3C, 0xFBC02D, 0x7B1FA2, 0xF57C00};
    private final CompoundTag d;

    public VehicleScreen(CompoundTag d) { super("Vehicul"); this.d = d; }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        panel(g, 4, 4, 452, 262, 0xF0141414, 0xFFFFB300);
        text(g, "VEHICUL", 14, 10, 0xFFFFB300, 1.5f);
        String cash = "Cash: " + money(d.getLong("cash"));
        g.drawString(font, cash, 446 - font.width(cash), 16, 0xFFFFFFFF, false);
        if (!d.getBoolean("found")) {
            g.drawString(font, "Nu e niciun vehicul în apropiere (8 blocuri). Urcă-te sau apropie-te de mașină.", 14, 50, 0xFFCCCCCC, false);
            return;
        }
        g.drawString(font, d.getString("name"), 14, 34, 0xFFFFFFFF, false);
        float fuel = d.getFloat("fuel"), cap = Math.max(1f, d.getFloat("cap"));
        g.drawString(font, "Benzină: " + (int) fuel + " / " + (int) cap + "   (2$ / unitate)", 14, 50, 0xFFFFE066, false);
        g.fill(14, 62, 446, 70, 0xFF2A2A2A);
        g.fill(14, 62, 14 + (int) (432 * fuel / cap), 70, 0xFFFFB300);
        btn(g, 14, 76, 90, 16, "+10 benzină", mx, my, 0xFF3A3A3A, 0xFFFFFFFF, () -> fuel(10));
        btn(g, 110, 76, 90, 16, "+50 benzină", mx, my, 0xFF3A3A3A, 0xFFFFFFFF, () -> fuel(50));
        btn(g, 206, 76, 90, 16, "Plin", mx, my, 0xFF3A3A3A, 0xFFFFFFFF, () -> fuel((int) cap));

        g.drawString(font, "Motor actual: " + (d.getString("engine").isEmpty() ? "-" : d.getString("engine")), 14, 102, 0xFFFFE066, false);
        for (int i = 0; i < TIERS.length; i++) {
            int t = i;
            btn(g, 14 + i * 108, 114, 104, 18, TIERS[i] + " " + money(TIER_PRICE[i]), mx, my, 0xFF3A3A3A, 0xFFFFFFFF, () -> action("veh_engine", "tier", t));
        }
        g.drawString(font, "Roți actuale: " + (d.getString("wheel").isEmpty() ? "-" : d.getString("wheel")), 14, 142, 0xFFFFE066, false);
        for (int i = 0; i < WHEELS.length; i++) {
            int t = i;
            btn(g, 14 + (i % 4) * 108, 154 + (i / 4) * 21, 104, 18, WHEELS[i] + " " + money(WHEEL_PRICE[i]), mx, my, 0xFF3A3A3A, 0xFFFFFFFF, () -> action("veh_wheel", "type", t));
        }
        g.drawString(font, "Culoare / interior (200$)", 14, 202, 0xFFFFE066, false);
        for (int i = 0; i < COLORS.length; i++) {
            int c = COLORS[i];
            btn(g, 14 + i * 34, 214, 30, 20, "", mx, my, 0xFF000000 | c, 0xFFFFFFFF, () -> action("veh_color", "rgb", c));
        }
    }

    private void fuel(int u) { action("veh_fuel", "units", u); }

    private void action(String a, String k, int v) {
        CompoundTag t = new CompoundTag();
        t.putInt(k, v);
        send(a, t);
    }
}
