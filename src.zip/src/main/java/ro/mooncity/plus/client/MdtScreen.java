package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** MDT in stilul MoonCity (neon albastru), fara butonul X (se inchide cu ESC). */
public class MdtScreen extends ScaledScreen {
    private static final String[] TABS = {"Acasă", "Aplicații", "Căutare", "Dosare", "Cazier", "Amenzi", "Permise", "Wanted", "Istoric", "Setări"};
    private static final int BLUE = 0xFF2F6BFF, BG = 0xFF050A1C, CARD = 0xFF0A1330;

    private final CompoundTag d;
    private int tab = 1;
    private String sub = "";
    private String search = "";

    public MdtScreen(CompoundTag d) { super("MDT"); this.d = d; }

    @Override
    public boolean charTyped(char c, int m) {
        if (tab == 2 && search.length() < 20 && c >= 32) { search += c; return true; }
        return super.charTyped(c, m);
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        if (tab == 2 && key == 259 && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        return super.keyPressed(key, sc, mod);
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        panel(g, 4, 4, 452, 262, BG, BLUE);
        g.renderOutline(6, 6, 448, 258, 0x442F6BFF);
        g.fillGradient(8, 8, 452, 40, 0xFF0A1740, BG);
        text(g, "§l§oMDT MOONCITY", 96, 10, 0xFFE8F0FF, 1.7f);
        text(g, TABS[tab], 96, 33, 0xFF4F8BFF, 1.0f);
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy | HH:mm"));
        g.drawString(font, "☾ " + time, 452 - 12 - font.width("☾ " + time), 16, 0xFFD6E4FF, false);

        // sidebar
        for (int i = 0; i < TABS.length; i++) {
            final int ti = i;
            int y = 46 + i * 17;
            boolean sel = i == tab;
            boolean hov = mx >= 12 && mx < 90 && my >= y && my < y + 15;
            btn(g, 12, y, 78, 15, TABS[i], mx, my, sel ? BLUE : (hov ? 0xFF121C40 : 0xFF0B1230), sel ? 0xFFFFFFFF : 0xFFC8D6FF, () -> { tab = ti; sub = ""; });
        }
        ResourceLocation logo = MoonLoading.texture();
        if (logo != null) {
            int lh = 38, lw = lh * MoonLoading.texW() / MoonLoading.texH();
            g.blit(logo, 12 + (78 - lw) / 2, 222, lw, lh, 0f, 0f, MoonLoading.texW(), MoonLoading.texH(), MoonLoading.texW(), MoonLoading.texH());
        }

        // content
        panel(g, 96, 46, 352, 212, 0xFF070E26, 0xFF1D3C95);
        if (!sub.isEmpty()) { drawSub(g, mx, my); return; }
        switch (tab) {
            case 0 -> home(g);
            case 1 -> apps(g, mx, my);
            case 2 -> searchTab(g);
            case 9 -> {
                text(g, "Setări", 106, 54, 0xFFFFFFFF, 1.2f);
                g.drawString(font, "Închide cu ESC. Datele sunt sincronizate cu serverul.", 106, 76, 0xFF9FB4E8, false);
            }
            default -> {
                text(g, TABS[tab], 106, 54, 0xFFFFFFFF, 1.2f);
                panel(g, 106, 76, 332, 40, CARD, 0xFF1D3C95);
                g.drawString(font, "Nu există înregistrări.", 116, 92, 0xFF9FB4E8, false);
            }
        }
    }

    private void home(GuiGraphics g) {
        text(g, "Bun venit, " + d.getString("name"), 106, 54, 0xFFFFFFFF, 1.3f);
        String[][] rows = {{"Job", d.getString("job") + " (niv. " + d.getInt("level") + ")"}, {"Cash", money(d.getLong("cash"))}, {"Cont bancar", money(d.getLong("bank"))}, {"Jucători online", String.valueOf(d.getList("players", 8).size())}};
        for (int i = 0; i < rows.length; i++) {
            int y = 80 + i * 34;
            panel(g, 106, y, 332, 28, CARD, 0xFF1D3C95);
            g.drawString(font, rows[i][0], 116, y + 10, 0xFF8FA8E8, false);
            g.drawString(font, rows[i][1], 438 - 10 - font.width(rows[i][1]), y + 10, 0xFFFFFFFF, false);
        }
    }

    private void apps(GuiGraphics g, int mx, int my) {
        text(g, "Aplicațiile disponibile", 106, 52, 0xFF4F8BFF, 1.2f);
        g.drawString(font, "Accesează toate funcțiile importante dintr-un singur loc!", 106, 66, 0xFF9FB4E8, false);
        String[][] cards = {
                {"Mașini deținute", "Vezi vehiculul din apropiere, benzina și piesele.", "vehicle"},
                {"Acte personale", "Verifică buletinul, permisele și licențele.", "acte"},
                {"Permise", "Vezi permisele disponibile (auto, barcă, avion).", "permise"},
                {"Acte și documente", "Verifică acte, licențe și alte documente.", "docs"},
                {"Proprietăți", "Vezi casele și proprietățile deținute.", "prop"},
                {"Cont bancar", "Verifică soldul și istoricul tranzacțiilor.", "bank"}};
        for (int i = 0; i < cards.length; i++) {
            int x = 106 + (i % 2) * 168, y = 80 + (i / 2) * 58;
            panel(g, x, y, 164, 54, CARD, 0xFF2A57D6);
            g.drawString(font, cards[i][0], x + 6, y + 5, 0xFFFFFFFF, false);
            wrap(g, cards[i][1], x + 6, y + 16, 152, 0xFF9FB4E8);
            String key = cards[i][2];
            btn(g, x + 98, y + 38, 62, 13, "Deschide →", mx, my, 0xFF1F6BFF, 0xFFFFFFFF, () -> {
                if (key.equals("vehicle")) send("vehicle"); else sub = key;
            });
        }
    }

    private void drawSub(GuiGraphics g, int mx, int my) {
        text(g, switch (sub) {
            case "acte" -> "Acte personale";
            case "permise" -> "Permise";
            case "docs" -> "Acte și documente";
            case "prop" -> "Proprietăți";
            default -> "Cont bancar";
        }, 106, 54, 0xFFFFFFFF, 1.3f);
        String[][] rows;
        switch (sub) {
            case "bank" -> rows = new String[][]{{"Cash", money(d.getLong("cash"))}, {"Sold bancar", money(d.getLong("bank"))}};
            case "acte" -> rows = new String[][]{{"Nume", d.getString("name")}, {"Buletin", "Valabil"}};
            case "permise" -> rows = new String[][]{{"Permis auto", "Valabil"}};
            case "docs" -> rows = new String[][]{{"Documente", "Vezi meniul K"}};
            default -> rows = new String[][]{{"Proprietăți", "Vezi meniul K"}};
        }
        for (int i = 0; i < rows.length; i++) {
            int y = 80 + i * 34;
            panel(g, 106, y, 332, 28, CARD, 0xFF1D3C95);
            g.drawString(font, rows[i][0], 116, y + 10, 0xFF8FA8E8, false);
            g.drawString(font, rows[i][1], 438 - 10 - font.width(rows[i][1]), y + 10, 0xFFFFFFFF, false);
        }
        btn(g, 106, 232, 70, 18, "← Înapoi", mx, my, 0xFF1F6BFF, 0xFFFFFFFF, () -> sub = "");
    }

    private void searchTab(GuiGraphics g) {
        text(g, "Căutare jucători", 106, 54, 0xFFFFFFFF, 1.2f);
        panel(g, 106, 74, 332, 18, 0xFF030816, BLUE);
        g.drawString(font, search + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), 112, 79, 0xFFFFFFFF, false);
        ListTag l = d.getList("players", 8);
        int n = 0;
        for (Tag t : l) {
            String name = t.getAsString();
            if (!name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            if (n >= 9) break;
            int y = 98 + n * 17;
            panel(g, 106, y, 332, 15, CARD, 0xFF1D3C95);
            g.drawString(font, name, 112, y + 4, 0xFFFFFFFF, false);
            n++;
        }
    }
}
