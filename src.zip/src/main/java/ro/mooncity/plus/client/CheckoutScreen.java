package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Casa de marcat: cos + bon fiscal + plata cash/card. */
public class CheckoutScreen extends ScaledScreen {
    private final CompoundTag d;

    public CheckoutScreen(CompoundTag d) { super("Casa"); this.d = d; }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        panel(g, 4, 4, 452, 262, 0xF0101216, 0xFF3A3F4A);
        text(g, "24/7 SUPERMARKET", 14, 10, 0xFFFFFFFF, 1.5f);
        g.drawString(font, "Produsele luate de pe rafturi", 14, 28, 0xFF9AA3B5, false);
        ListTag cart = d.getList("cart", 10);
        if (cart.isEmpty()) g.drawString(font, "Coșul e gol. Apasă click-dreapta pe rafturi.", 14, 50, 0xFFCCCCCC, false);
        for (int i = 0; i < cart.size() && i < 11; i++) {
            CompoundTag c = cart.getCompound(i);
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(c.getString("id")));
            int y = 44 + i * 19;
            panel(g, 12, y, 250, 17, 0xFF1B1F27, 0xFF2D3340);
            if (item != null) {
                g.renderItem(new ItemStack(item), 14, y);
                g.drawString(font, item.getDescription().getString() + " x" + c.getInt("count"), 34, y + 5, 0xFFFFFFFF, false);
            }
            String p = money((long) c.getInt("price") * c.getInt("count"));
            g.drawString(font, p, 236 - font.width(p), y + 5, 0xFF6DDB5A, false);
            int idx = i;
            btn(g, 240, y + 2, 18, 13, "x", mx, my, 0xFFB23B3B, 0xFFFFFFFF, () -> {
                CompoundTag t = new CompoundTag();
                t.putInt("i", idx);
                send("shop_remove", t);
            });
        }
        // bon
        panel(g, 274, 44, 174, 214, 0xFFF4F4F0, 0xFF999999);
        g.drawCenteredString(font, "BON FISCAL", 361, 52, 0xFF111111);
        long total = d.getLong("total");
        g.drawString(font, "TOTAL", 282, 76, 0xFF111111, false);
        String tt = money(total);
        g.drawString(font, tt, 440 - font.width(tt), 76, 0xFF111111, false);
        g.drawString(font, "Cash: " + money(d.getLong("cash")), 282, 100, 0xFF444444, false);
        g.drawString(font, "Card: " + money(d.getLong("bank")), 282, 112, 0xFF444444, false);
        btn(g, 282, 150, 158, 20, "Plătește CASH", mx, my, 0xFF2E7D32, 0xFFFFFFFF, () -> pay(true));
        btn(g, 282, 176, 158, 20, "Plătește cu CARDUL", mx, my, 0xFF1565C0, 0xFFFFFFFF, () -> pay(false));
        btn(g, 282, 202, 158, 16, "Golește coșul", mx, my, 0xFF8E2A2A, 0xFFFFFFFF, () -> send("shop_clear"));
    }

    private void pay(boolean cash) {
        CompoundTag t = new CompoundTag();
        t.putBoolean("cash", cash);
        send("shop_pay", t);
    }
}
