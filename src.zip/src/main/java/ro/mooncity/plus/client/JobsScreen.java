package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

/** Job Center - carduri cu "Sign Up" galben. */
public class JobsScreen extends ScaledScreen {
    private final CompoundTag d;

    public JobsScreen(CompoundTag d) { super("Job Center"); this.d = d; }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        panel(g, 4, 4, 452, 262, 0xF0222222, 0xFF444444);
        text(g, "Job Center", 14, 10, 0xFF6DDB5A, 1.5f);
        String cur = d.getString("job");
        String info = cur.isEmpty() ? "Fără job" : "Job activ: " + cur + " | Nivel " + d.getInt("level") + " (" + d.getInt("xp") + "/100 XP)";
        g.drawString(font, info, 446 - font.width(info), 16, 0xFFFFE066, false);
        ListTag jobs = d.getList("jobs", 10);
        for (int i = 0; i < jobs.size(); i++) {
            CompoundTag j = jobs.getCompound(i);
            int x = 12 + (i % 3) * 147, y = 36 + (i / 3) * 112;
            panel(g, x, y, 140, 106, 0xFF2E2E2E, 0xFF3C3C3C);
            g.fill(x + 4, y + 4, x + 136, y + 38, j.getInt("color"));
            g.fill(x + 4, y + 22, x + 136, y + 38, 0x66000000);
            g.drawCenteredString(font, j.getString("name"), x + 70, y + 41, 0xFFFFD43B);
            g.drawCenteredString(font, "Pay " + money(j.getInt("pay")) + j.getString("unit"), x + 70, y + 52, 0xFF6DDB5A);
            wrap(g, j.getString("desc"), x + 6, y + 64, 128, 0xFFCCCCCC);
            String id = j.getString("id");
            boolean mine = id.equals(cur);
            btn(g, x + 4, y + 90, 132, 13, mine ? "Renunță" : "Sign Up", mx, my, mine ? 0xFFB23B3B : 0xFFFFC107, mine ? 0xFFFFFFFF : 0xFF111111, () -> {
                CompoundTag t = new CompoundTag();
                t.putString("job", id);
                send(mine ? "job_quit" : "job_join", t);
            });
        }
    }
}
