package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;

/** Minigame electrician: reține ordinea afișată și apasă firele în aceeași ordine. */
public class ElectricScreen extends ScaledScreen {
    private static final int[] COL = {0xFFE53935, 0xFF1E88E5, 0xFFFDD835, 0xFF43A047};
    private static final String[] NAME = {"Roșu", "Albastru", "Galben", "Verde"};
    private final int[] seq;
    private final int[] ans = new int[4];
    private int n = 0;
    private final long start = System.currentTimeMillis();

    public ElectricScreen(CompoundTag d) { super("Panou electric"); this.seq = d.getIntArray("seq"); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        panel(g, 100, 40, 260, 190, 0xF0141414, 0xFFFFC107);
        g.drawCenteredString(font, "PANOU ELECTRIC", 230, 48, 0xFFFFC107);
        boolean show = System.currentTimeMillis() - start < 3500;
        g.drawCenteredString(font, show ? "Memorează ordinea:" : "Apasă firele în ordinea memorată:", 230, 66, 0xFFFFFFFF);
        for (int i = 0; i < 4 && seq.length == 4; i++) {
            int x = 140 + i * 50;
            g.fill(x, 82, x + 40, 100, show ? COL[seq[i]] : 0xFF333333);
        }
        for (int i = 0; i < 4; i++) {
            int c = i;
            btn(g, 140 + i * 50, 120, 40, 40, "", mx, my, COL[i], 0xFFFFFFFF, () -> press(c));
            g.drawCenteredString(font, NAME[i], 160 + i * 50, 165, 0xFFCCCCCC);
        }
        g.drawCenteredString(font, "Selectat: " + n + "/4", 230, 200, 0xFF9AA3B5);
    }

    private void press(int c) {
        if (System.currentTimeMillis() - start < 3500 || n >= 4) return;
        ans[n++] = c;
        if (n == 4) {
            CompoundTag t = new CompoundTag();
            t.putIntArray("seq", ans);
            send("elec_submit", t);
            onClose();
        }
    }
}
