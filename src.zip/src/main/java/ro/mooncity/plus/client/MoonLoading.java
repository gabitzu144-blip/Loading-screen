package ro.mooncity.plus.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.io.InputStream;
import java.util.Random;

/** Loading screen MoonCity: fundal noapte + stele + logo MOON + bara de progres. */
public class MoonLoading {
    private static final ResourceLocation TEX = new ResourceLocation("mooncityplus", "dynamic/moon_logo");
    private static boolean tried, ok;
    private static int tw, th;
    private static final int[][] STARS = new int[90][3];
    private static float shown;

    static {
        Random r = new Random(1337);
        for (int[] s : STARS) { s[0] = r.nextInt(10000); s[1] = r.nextInt(10000); s[2] = 80 + r.nextInt(150); }
    }

    public static ResourceLocation texture() {
        load();
        return ok ? TEX : null;
    }

    public static int texW() { return tw; }
    public static int texH() { return th; }

    private static void load() {
        if (tried) return;
        tried = true;
        try (InputStream in = MoonLoading.class.getResourceAsStream("/assets/mooncityplus/textures/gui/moon_logo.png")) {
            NativeImage img = NativeImage.read(in);
            tw = img.getWidth();
            th = img.getHeight();
            Minecraft.getInstance().getTextureManager().register(TEX, new DynamicTexture(img));
            ok = true;
        } catch (Throwable t) { ok = false; }
    }

    /** Ecranul de intrare pe server: fundal + logo + bara animata + text. */
    public static void renderJoin(GuiGraphics g, String label) {
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        drawBase(g, w, h);
        int bw = Math.min(240, w - 40), bh = 5, bx = (w - bw) / 2, by = h - h / 6;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF2a3a70);
        g.fill(bx, by, bx + bw, by + bh, 0xFF070b1a);
        float t = (System.currentTimeMillis() % 1800) / 1800f;
        int seg = bw / 3, start = (int) ((bw + seg) * t) - seg;
        int x1 = Math.max(0, start), x2 = Math.min(bw, start + seg);
        if (x2 > x1) g.fill(bx + x1, by, bx + x2, by + bh, 0xFFB9D3FF);
        g.drawCenteredString(mc.font, label, w / 2, by + 14, 0xFFB9D3FF);
    }

    public static void render(GuiGraphics g, float progress) {
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        drawBase(g, w, h);
        shown += (Math.min(1f, Math.max(0f, progress)) - shown) * 0.1f;
        int bw = Math.min(240, w - 40), bh = 5, bx = (w - bw) / 2, by = h - h / 6;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF2a3a70);
        g.fill(bx, by, bx + bw, by + bh, 0xFF070b1a);
        g.fill(bx, by, bx + (int) (bw * shown), by + bh, 0xFFB9D3FF);
    }

    private static void drawBase(GuiGraphics g, int w, int h) {
        g.fillGradient(0, 0, w, h, 0xFF03050c, 0xFF0b1330);
        long t = System.currentTimeMillis();
        for (int[] s : STARS) {
            int x = s[0] * w / 10000, y = s[1] * h / 10000;
            double tw2 = 0.55 + 0.45 * Math.sin(t / 600.0 + s[0]);
            int a = (int) (s[2] * tw2);
            g.fill(x, y, x + 1, y + 1, (a << 24) | 0xFFFFFF);
        }
        load();
        if (ok) {
            int dh = Math.min(h / 2, 180);
            int dw = dh * tw / th;
            RenderSystem.enableBlend();
            g.blit(TEX, (w - dw) / 2, h / 2 - dh / 2 - 12, dw, dh, 0f, 0f, tw, th, tw, th);
            RenderSystem.disableBlend();
        }
    }
}
