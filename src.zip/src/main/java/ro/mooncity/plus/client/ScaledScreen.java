package ro.mooncity.plus.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import ro.mooncity.plus.Net;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ecran cu spatiu virtual 460x270, scalat automat; butoane prin regiuni. */
public abstract class ScaledScreen extends Screen {
    protected static final int VW = 460, VH = 270;
    protected float s = 1, ox, oy;
    private final List<int[]> regions = new ArrayList<>();
    private final List<Runnable> actions = new ArrayList<>();

    protected ScaledScreen(String title) { super(Component.literal(title)); }

    @Override public boolean isPauseScreen() { return false; }

    protected abstract void draw(GuiGraphics g, int mx, int my);

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        s = Math.min(width / (float) VW, height / (float) VH);
        ox = (width - VW * s) / 2f;
        oy = (height - VH * s) / 2f;
        regions.clear();
        actions.clear();
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1f);
        draw(g, (int) ((mx - ox) / s), (int) ((my - oy) / s));
        g.pose().popPose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        int vx = (int) ((mx - ox) / s), vy = (int) ((my - oy) / s);
        for (int i = regions.size() - 1; i >= 0; i--) {
            int[] r = regions.get(i);
            if (vx >= r[0] && vx < r[0] + r[2] && vy >= r[1] && vy < r[1] + r[3]) { actions.get(i).run(); return true; }
        }
        return super.mouseClicked(mx, my, b);
    }

    protected void btn(GuiGraphics g, int x, int y, int w, int h, String label, int mx, int my, int fill, int fg, Runnable r) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        g.fill(x, y, x + w, y + h, hov ? lighten(fill) : fill);
        g.renderOutline(x, y, w, h, 0x66FFFFFF);
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, fg, false);
        regions.add(new int[]{x, y, w, h});
        actions.add(r);
    }

    protected void panel(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        g.fill(x, y, x + w, y + h, fill);
        g.renderOutline(x, y, w, h, border);
    }

    protected void text(GuiGraphics g, String t, int x, int y, int color, float sc) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(sc, sc, 1f);
        g.drawString(font, t, 0, 0, color, false);
        g.pose().popPose();
    }

    protected void wrap(GuiGraphics g, String t, int x, int y, int w, int color) {
        int yy = y;
        for (var line : font.split(Component.literal(t), w)) { g.drawString(font, line, x, yy, color, false); yy += 10; }
    }

    protected static int lighten(int c) {
        int r = Math.min(255, ((c >> 16) & 255) + 28), gg = Math.min(255, ((c >> 8) & 255) + 28), b = Math.min(255, (c & 255) + 28);
        return 0xFF000000 | (r << 16) | (gg << 8) | b;
    }

    protected static String money(long v) { return "$" + String.format(Locale.US, "%,d", v); }

    protected void send(String action, CompoundTag t) { Net.CHANNEL.sendToServer(new Net.ActionC2S(action, t)); }
    protected void send(String action) { send(action, new CompoundTag()); }
}
