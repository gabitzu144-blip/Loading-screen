package ro.mooncity.plus.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.plus.MoonCityPlus;
import ro.mooncity.plus.Net;
import ro.mooncity.plus.Reg;

public class ClientHooks {

    public static void open(int id, CompoundTag t) {
        Minecraft mc = Minecraft.getInstance();
        switch (id) {
            case Net.MDT -> mc.setScreen(new MdtScreen(t));
            case Net.JOBS -> mc.setScreen(new JobsScreen(t));
            case Net.CHECKOUT -> mc.setScreen(new CheckoutScreen(t));
            case Net.VEHICLE -> mc.setScreen(new VehicleScreen(t));
            case Net.ELECTRIC -> mc.setScreen(new ElectricScreen(t));
            default -> { }
        }
    }

    private static void send(String a) { Net.CHANNEL.sendToServer(new Net.ActionC2S(a, new CompoundTag())); }

    /** Pune ecranul MoonCity peste ecranele de conectare / incarcare la intrarea pe server. */
    @Mod.EventBusSubscriber(value = Dist.CLIENT, modid = MoonCityPlus.ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class JoinScreens {
        @SubscribeEvent
        public static void render(ScreenEvent.Render.Post e) {
            var sc = e.getScreen();
            String label;
            if (sc instanceof ConnectScreen) label = "Se conectează la server...";
            else if (sc instanceof ReceivingLevelScreen || sc instanceof LevelLoadingScreen) label = "Se încarcă lumea...";
            else if (sc instanceof ProgressScreen) label = "Se încarcă...";
            else return;
            MoonLoading.renderJoin(e.getGuiGraphics(), label);
        }
    }

    /** Adauga butoane in meniul K existent (ro.mooncity.client.MenuScreen). */
    @Mod.EventBusSubscriber(value = Dist.CLIENT, modid = MoonCityPlus.ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class Forge {
        @SubscribeEvent
        public static void init(ScreenEvent.Init.Post e) {
            if (!e.getScreen().getClass().getName().equals("ro.mooncity.client.MenuScreen")) return;
            String[] labels = {"MDT", "Job Center", "Vehicul (benzină/piese)", "Casa / Coș magazin"};
            String[] acts = {"mdt", "jobs", "vehicle", "checkout"};
            for (int i = 0; i < labels.length; i++) {
                String a = acts[i];
                e.addListener(Button.builder(Component.literal(labels[i]), b -> send(a)).bounds(6, 6 + i * 22, 130, 20).build());
            }
        }
    }

    @Mod.EventBusSubscriber(value = Dist.CLIENT, modid = MoonCityPlus.ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Mod_ {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerBlockEntityRenderer(Reg.SHELF_BE.get(), ShelfRenderer::new);
        }
    }
}
