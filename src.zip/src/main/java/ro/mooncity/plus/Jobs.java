package ro.mooncity.plus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Jobs {
    public record Job(String id, String name, String desc, int pay, String unit, int color) { }

    public static final List<Job> ALL = List.of(
            new Job("padurar", "Pădurar", "Taie copaci și câștigi pe fiecare buștean tăiat.", 15, "/buștean", 0xFF4CAF50),
            new Job("miner", "Miner", "Sapă minereuri în mină. Plătit pentru fiecare minereu.", 40, "/minereu", 0xFF9E9E9E),
            new Job("pescar", "Pescar", "Pescuiește și vinde peștele. Plătit per captură.", 35, "/captură", 0xFF29B6F6),
            new Job("electrician", "Electrician", "Repară panourile electrice (minigame cu fire).", 250, "/reparație", 0xFFFFC107),
            new Job("fermier", "Fermier", "Recoltează culturile coapte și câștigi per recoltă.", 20, "/recoltă", 0xFF8BC34A));

    private static final Map<UUID, int[]> PENDING = new HashMap<>();
    private static final Map<Long, Long> BOX_COOLDOWN = new HashMap<>();

    public static String current(ServerPlayer p) { return PlusData.plus(p).getString("job"); }

    public static String nameOf(String id) {
        for (Job j : ALL) if (j.id().equals(id)) return j.name();
        return "Șomer";
    }

    private static Job get(String id) {
        for (Job j : ALL) if (j.id().equals(id)) return j;
        return null;
    }

    public static int xp(ServerPlayer p) { return PlusData.plus(p).getInt("jobxp"); }
    public static int level(ServerPlayer p) { return 1 + xp(p) / 100; }

    public static void open(ServerPlayer sp) {
        CompoundTag d = new CompoundTag();
        d.putString("job", current(sp));
        d.putInt("level", level(sp));
        d.putInt("xp", xp(sp) % 100);
        ListTag l = new ListTag();
        for (Job j : ALL) {
            CompoundTag c = new CompoundTag();
            c.putString("id", j.id());
            c.putString("name", j.name());
            c.putString("desc", j.desc());
            c.putInt("pay", j.pay());
            c.putString("unit", j.unit());
            c.putInt("color", j.color());
            l.add(c);
        }
        d.put("jobs", l);
        Net.open(sp, Net.JOBS, d);
    }

    public static void join(ServerPlayer sp, String id) {
        Job j = get(id);
        if (j == null) return;
        if (!id.equals(current(sp))) PlusData.plus(sp).putInt("jobxp", 0);
        PlusData.plus(sp).putString("job", id);
        Actions.msg(sp, "Acum ești " + j.name() + "!");
        open(sp);
    }

    public static void quit(ServerPlayer sp) {
        PlusData.plus(sp).putString("job", "");
        Actions.msg(sp, "Ai renunțat la job.");
        open(sp);
    }

    public static void reward(ServerPlayer sp, String id) {
        Job j = get(id);
        if (j == null) return;
        int lvl = level(sp);
        long pay = Math.round(j.pay() * (1.0 + 0.1 * (lvl - 1)));
        PlusData.setCash(sp, PlusData.cash(sp) + pay);
        PlusData.plus(sp).putInt("jobxp", xp(sp) + 1);
        PlusData.sync(sp);
        int nl = level(sp);
        if (nl > lvl) Actions.msg(sp, j.name() + " nivel " + nl + "! Plata crește cu 10%.");
        else Actions.msg(sp, "+$" + pay + " (" + j.name() + " niv. " + lvl + ")");
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer sp) || sp.isCreative()) return;
        String job = current(sp);
        if (job.isEmpty()) return;
        BlockState st = e.getState();
        switch (job) {
            case "padurar" -> { if (st.is(BlockTags.LOGS)) reward(sp, job); }
            case "miner" -> { if (st.is(Tags.Blocks.ORES)) reward(sp, job); }
            case "fermier" -> { if (st.getBlock() instanceof CropBlock cb && cb.isMaxAge(st)) reward(sp, job); }
            default -> { }
        }
    }

    @SubscribeEvent
    public static void onFish(ItemFishedEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && "pescar".equals(current(sp)) && !e.getDrops().isEmpty()) reward(sp, "pescar");
    }

    // ---- Electrician ----
    public static void openElectric(ServerPlayer sp, BlockPos pos) {
        if (!"electrician".equals(current(sp))) { Actions.msg(sp, "Trebuie să fii Electrician (Job Center)."); return; }
        long now = sp.level().getGameTime();
        Long last = BOX_COOLDOWN.get(pos.asLong());
        if (last != null && now - last < 20 * 120) { Actions.msg(sp, "Panoul a fost reparat recent."); return; }
        int[] seq = {0, 1, 2, 3};
        for (int i = 3; i > 0; i--) {
            int k = sp.getRandom().nextInt(i + 1);
            int tmp = seq[i]; seq[i] = seq[k]; seq[k] = tmp;
        }
        PENDING.put(sp.getUUID(), new int[]{seq[0], seq[1], seq[2], seq[3], (int) (pos.asLong() >> 32), (int) pos.asLong()});
        CompoundTag d = new CompoundTag();
        d.putIntArray("seq", seq);
        Net.open(sp, Net.ELECTRIC, d);
    }

    public static void submitElectric(ServerPlayer sp, int[] ans) {
        int[] p = PENDING.remove(sp.getUUID());
        if (p == null) return;
        if (Arrays.equals(Arrays.copyOf(p, 4), ans)) {
            long key = (((long) p[4]) << 32) | (p[5] & 0xFFFFFFFFL);
            BOX_COOLDOWN.put(key, sp.level().getGameTime());
            reward(sp, "electrician");
        } else Actions.msg(sp, "Ai greșit ordinea firelor! Scurtcircuit.");
    }
}
