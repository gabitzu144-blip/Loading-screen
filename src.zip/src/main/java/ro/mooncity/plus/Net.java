package ro.mooncity.plus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Net {
    private static final String PROTO = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MoonCityPlus.ID, "main"), () -> PROTO, PROTO::equals, PROTO::equals);

    public static final int MDT = 1, JOBS = 2, CHECKOUT = 3, VEHICLE = 4, ELECTRIC = 5;

    public static void init() {
        CHANNEL.registerMessage(0, OpenScreenS2C.class, OpenScreenS2C::enc, OpenScreenS2C::dec, OpenScreenS2C::handle);
        CHANNEL.registerMessage(1, ActionC2S.class, ActionC2S::enc, ActionC2S::dec, ActionC2S::handle);
    }

    public static void open(ServerPlayer sp, int id, CompoundTag tag) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenS2C(id, tag));
    }

    public static final class OpenScreenS2C {
        final int id;
        final CompoundTag tag;

        public OpenScreenS2C(int id, CompoundTag tag) { this.id = id; this.tag = tag; }

        static void enc(OpenScreenS2C m, FriendlyByteBuf b) { b.writeInt(m.id); b.writeNbt(m.tag); }

        static OpenScreenS2C dec(FriendlyByteBuf b) { return new OpenScreenS2C(b.readInt(), b.readNbt()); }

        static void handle(OpenScreenS2C m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.plus.client.ClientHooks.open(m.id, m.tag)));
            c.get().setPacketHandled(true);
        }
    }

    public static final class ActionC2S {
        public final String action;
        public final CompoundTag tag;

        public ActionC2S(String action, CompoundTag tag) { this.action = action; this.tag = tag == null ? new CompoundTag() : tag; }

        static void enc(ActionC2S m, FriendlyByteBuf b) { b.writeUtf(m.action, 64); b.writeNbt(m.tag); }

        static ActionC2S dec(FriendlyByteBuf b) { return new ActionC2S(b.readUtf(64), b.readNbt()); }

        static void handle(ActionC2S m, Supplier<NetworkEvent.Context> c) {
            ServerPlayer sp = c.get().getSender();
            c.get().enqueueWork(() -> { if (sp != null) Actions.handle(sp, m.action, m.tag); });
            c.get().setPacketHandled(true);
        }
    }
}
