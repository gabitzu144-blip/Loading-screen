package ro.mooncity.plus;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class Reg {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MoonCityPlus.ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoonCityPlus.ID);
    public static final DeferredRegister<BlockEntityType<?>> BES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MoonCityPlus.ID);

    public static final RegistryObject<Block> SHELF = BLOCKS.register("shop_shelf",
            () -> new ShelfBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2f).noOcclusion()));
    public static final RegistryObject<Block> REGISTER = BLOCKS.register("cash_register",
            () -> new RegisterBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2f).noOcclusion()));
    public static final RegistryObject<Block> ELECTRIC = BLOCKS.register("electric_box",
            () -> new ElectricBoxBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3f).noOcclusion()));

    public static final RegistryObject<Item> SHELF_ITEM = ITEMS.register("shop_shelf", () -> new BlockItem(SHELF.get(), new Item.Properties()));
    public static final RegistryObject<Item> REGISTER_ITEM = ITEMS.register("cash_register", () -> new BlockItem(REGISTER.get(), new Item.Properties()));
    public static final RegistryObject<Item> ELECTRIC_ITEM = ITEMS.register("electric_box", () -> new BlockItem(ELECTRIC.get(), new Item.Properties()));
    public static final RegistryObject<Item> TABLET = ITEMS.register("mdt_tablet", () -> new MdtItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<BlockEntityType<ShelfBE>> SHELF_BE = BES.register("shop_shelf",
            () -> BlockEntityType.Builder.of(ShelfBE::new, SHELF.get()).build(null));

    public static void init(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BES.register(bus);
    }

    public static void tab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            e.accept(SHELF_ITEM);
            e.accept(REGISTER_ITEM);
            e.accept(ELECTRIC_ITEM);
        }
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) e.accept(TABLET);
    }
}
