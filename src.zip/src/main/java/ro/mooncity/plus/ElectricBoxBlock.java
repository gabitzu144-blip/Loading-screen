package ro.mooncity.plus;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Panou electric: tinta pentru jobul de electrician (minigame cu fire). */
public class ElectricBoxBlock extends Block {
    public ElectricBoxBlock(Properties p) { super(p); }

    @Override
    public InteractionResult use(BlockState st, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level.isClientSide && player instanceof ServerPlayer sp) Jobs.openElectric(sp, pos);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
