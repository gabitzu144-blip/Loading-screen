package ro.mooncity.plus;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class ShelfBE extends BlockEntity {
    public ItemStack item = ItemStack.EMPTY;
    public int price = 0;

    public ShelfBE(BlockPos pos, BlockState state) { super(Reg.SHELF_BE.get(), pos, state); }

    @Override
    protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.put("item", item.save(new CompoundTag()));
        t.putInt("price", price);
    }

    @Override
    public void load(CompoundTag t) {
        super.load(t);
        item = ItemStack.of(t.getCompound("item"));
        price = t.getInt("price");
    }

    @Override
    public CompoundTag getUpdateTag() { return saveWithoutMetadata(); }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }

    public void sync() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }
}
